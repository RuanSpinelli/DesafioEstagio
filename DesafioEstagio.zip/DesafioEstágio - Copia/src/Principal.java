import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;


public class Principal {
    public static void main(String[] args) {
        List<Funcionario> funcionarios = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");

        funcionarios.add(new Funcionario("Maria", LocalDate.parse("18/10/2000", formatter), new BigDecimal("2009.44"), "Operador"));
        funcionarios.add(new Funcionario("João", LocalDate.parse("12/05/1990", formatter), new BigDecimal("2284.38"), "Operador"));
        funcionarios.add(new Funcionario("Caio", LocalDate.parse("02/05/1961", formatter), new BigDecimal("9836.14"), "Coordenador"));
        funcionarios.add(new Funcionario("Miguel", LocalDate.parse("14/10/1988", formatter), new BigDecimal("19119.88"), "Diretor"));
        funcionarios.add(new Funcionario("Alice", LocalDate.parse("05/01/1995", formatter), new BigDecimal("2234.68"), "Recepcionista"));
        funcionarios.add(new Funcionario("Heitor", LocalDate.parse("19/11/1999", formatter), new BigDecimal("1582.72"), "Operador"));
        funcionarios.add(new Funcionario("Arthur", LocalDate.parse("31/03/1993", formatter), new BigDecimal("4071.84"), "Contador"));
        funcionarios.add(new Funcionario("Laura", LocalDate.parse("08/07/1994", formatter), new BigDecimal("3017.45"), "Gerente"));
        funcionarios.add(new Funcionario("Heloísa", LocalDate.parse("24/05/2003", formatter), new BigDecimal("1606.85"), "Eletricista"));
        funcionarios.add(new Funcionario("Helena", LocalDate.parse("02/09/1996", formatter), new BigDecimal("2799.93"), "Gerente"));

        // Remove João
        funcionarios.removeIf(f -> f.getNome().equals("João"));

        // Mostra os funcionários e suas funções
        for (Funcionario funcionario : funcionarios) {
            System.out.println("Nome: " + funcionario.getNome() + 
                ", Data de Nascimento: " + funcionario.getDataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
                ", Salário: " + String.format(Locale.GERMANY, "%,.2f", funcionario.getSalario()) +
                ", Função: " + funcionario.getFuncao());
        }
        //Só pra pular linha
        System.out.println();

        // 3.4 – Atualizar salários com aumento de 10%
        for (Funcionario funcionario : funcionarios) {
            BigDecimal aumento = funcionario.getSalario().multiply(new BigDecimal("0.10"));
            funcionario.setSalario(funcionario.getSalario().add(aumento));
        }
        //Só pra pular linha
        System.out.println();

        // 3.5 – Agrupar funcionários por função
        Map<String, List<Funcionario>> funcionariosPorFuncao = funcionarios.stream().collect(Collectors.groupingBy(Funcionario::getFuncao));

        //Só pra pular linha
        System.out.println();

        //3.6 – Imprimir funcionários agrupados por função
        for (Map.Entry<String, List<Funcionario>> entry : funcionariosPorFuncao.entrySet()) {
            System.out.println("Função: " + entry.getKey());
            for (Funcionario funcionario : entry.getValue()) {
                System.out.println("\tNome: " + funcionario.getNome() + 
                    ", Data de Nascimento: " + funcionario.getDataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
                    ", Salário: " + String.format(Locale.GERMANY, "%,.2f", funcionario.getSalario()) +
                    ", Função: " + funcionario.getFuncao());
            }
        }

        //Só pra pular linha
        System.out.println();

        //3.8 – Imprimir funcionários que fazem aniversário nos meses 10 e 12
        System.out.println("Aniversariantes de Outubro e Dezembro:");
        for (Funcionario funcionario : funcionarios) {
        
            int mesNascimento = funcionario.getDataNascimento().getMonthValue();
        
            if (mesNascimento == 10 || mesNascimento == 12) {
            
                System.out.println("Nome: " + funcionario.getNome() + ", Data de Nascimento: " + 
                funcionario.getDataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
                ", Salário: " + String.format(Locale.GERMANY, "%,.2f", funcionario.getSalario()) +
                ", Função: " + funcionario.getFuncao());
            }
        }

        //Só pra pular linha
        System.out.println();

        //3.9 – Imprimir o funcionário com a maior idade

        Funcionario maisVelho = funcionarios.stream().min((f1, f2) -> f1.getDataNascimento().compareTo(f2.getDataNascimento())).orElse(null);

        if (maisVelho != null) {
        int idade = LocalDate.now().getYear() - maisVelho.getDataNascimento().getYear();
        System.out.println("Funcionário mais velho: Nome: " + maisVelho.getNome() + ", Idade: " + idade + " anos");
        }

        //Só pra pular linha
        System.out.println();

        //3.10 – Imprimir a lista de funcionários por ordem alfabética

        List<Funcionario> funcionariosOrdenados = funcionarios.stream()
    .sorted((f1, f2) -> f1.getNome().compareToIgnoreCase(f2.getNome()))
    .collect(Collectors.toList());

    System.out.println("Funcionários em ordem alfabética:");
    for (Funcionario funcionario : funcionariosOrdenados) {
        System.out.println("Nome: " + funcionario.getNome() + 
            ", Data de Nascimento: " + funcionario.getDataNascimento().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) + 
            ", Salário: " + String.format(Locale.GERMANY, "%,.2f", funcionario.getSalario()) +
            ", Função: " + funcionario.getFuncao());
    }

    //Só pra pular linha
    System.out.println();

    //3.11 – Imprimir o total dos salários dos funcionários
    BigDecimal totalSalarios = funcionarios.stream().map(Funcionario::getSalario).reduce(BigDecimal.ZERO, BigDecimal::add);

    System.out.println("Total dos salários: " + String.format(Locale.GERMANY, "%,.2f", totalSalarios));

    //Só pra pular linha
    System.out.println();

    //3.12 – Imprimir quantos salários mínimos ganha cada funcionário
    BigDecimal salarioMinimo = new BigDecimal("1212.00");

    System.out.println("Quantidade de salários mínimos por funcionário:");
    for (Funcionario funcionario : funcionarios) {
        BigDecimal qtdSalariosMinimos = funcionario.getSalario().divide(salarioMinimo, 2, BigDecimal.ROUND_HALF_UP);
        System.out.println("Nome: " + funcionario.getNome() + 
        ", Salários Mínimos: " + String.format(Locale.GERMANY, "%,.2f", qtdSalariosMinimos));
    }


        
    }
}
